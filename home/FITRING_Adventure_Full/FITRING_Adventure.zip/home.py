import pygame
import sys
from pathlib import Path

# --------- ตั้งค่า ----------
TARGET_WIDTH = 960
TARGET_HEIGHT = 540
FPS = 60

# --------- เริ่ม ----------
pygame.init()
clock = pygame.time.Clock()
screen = pygame.display.set_mode((TARGET_WIDTH, TARGET_HEIGHT))
pygame.display.set_caption("FITRING Adventure - Home Screen")

# --------- assets ----------
ASSET_DIR = Path(__file__).parent
bg_path = ASSET_DIR / "pg/bg1.png"
button_path = ASSET_DIR / "pg/start2.png"  
name_path = ASSET_DIR / "pg/name.png"

# --------- โหลดรูป ----------
background = pygame.image.load(str(bg_path)).convert_alpha() if bg_path.exists() else None
if background:
    background = pygame.transform.smoothscale(background, (TARGET_WIDTH, TARGET_HEIGHT))

button_img = pygame.image.load(str(button_path)).convert_alpha() if button_path.exists() else None
if button_img:
    button_img = pygame.transform.smoothscale(button_img, (180, 90))
    button_rect = button_img.get_rect(center=(TARGET_WIDTH//2, TARGET_HEIGHT - 100))
else:
    button_rect = pygame.Rect((TARGET_WIDTH - 180)//2, TARGET_HEIGHT - 120, 180, 60)

name_img = pygame.image.load(str(name_path)).convert_alpha() if name_path.exists() else None
if name_img:
    name_img = pygame.transform.smoothscale(name_img, (700, 200))
    name_rect = name_img.get_rect(center=(TARGET_WIDTH//2, TARGET_HEIGHT//2 - 50))

# --------- ฟังก์ชันเมาส์ ----------
def is_hover(rect, mouse_pos):
    return rect.collidepoint(mouse_pos)

# --------- Home Screen Loop ----------
running = True
while running:
    dt = clock.tick(FPS) / 1000.0
    mouse_pos = pygame.mouse.get_pos()
    mouse_pressed = pygame.mouse.get_pressed()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # คลิกปุ่ม Start
    if is_hover(button_rect, mouse_pos) and mouse_pressed[0]:
        print("Start Game clicked!")
        import character
        running = False

    # --------- วาดหน้าจอ ---------
    if background:
        screen.blit(background, (0, 0))
    else:
        screen.fill((40, 40, 50))

    if name_img:
        screen.blit(name_img, name_rect)

    if button_img:
        screen.blit(button_img, button_rect)
    else:
        pygame.draw.rect(screen, (200, 80, 80), button_rect, border_radius=12)

    pygame.display.flip()

pygame.quit()
sys.exit()
