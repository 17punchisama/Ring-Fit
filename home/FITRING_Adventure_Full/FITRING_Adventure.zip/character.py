import pygame
import sys
from pathlib import Path
import subprocess

# --------- ตั้งค่า ----------
TARGET_WIDTH = 960
TARGET_HEIGHT = 540
FPS = 60

# --------- เริ่ม ----------
pygame.init()
clock = pygame.time.Clock()
screen = pygame.display.set_mode((TARGET_WIDTH, TARGET_HEIGHT))
pygame.display.set_caption("FITRING Adventure - Character Selection")

# --------- โหลด assets ----------
ASSET_DIR = Path(__file__).parent
bg_path = ASSET_DIR / "pg/bg1.png"
char1_path = ASSET_DIR / "pg/loongmad1.png"
char2_path = ASSET_DIR / "pg/nakdab.png"
char_btn_path = ASSET_DIR / "pg/character.png"
confirm_path = ASSET_DIR / "pg/confirm.png" 
font_path = ASSET_DIR / "fonts/Itim-Regular.ttf"
titlebox_path = ASSET_DIR / "pg/TitleBox.png"
circlebox_path = ASSET_DIR / "pg/CircleBox.png"
arrow_path = ASSET_DIR / "pg/LeftArrowButton.png"

BOX_SIZE = (370, 370)
BUTTON_SIZE = (180, 90)
CONFIRM_SIZE = (100, 30)

def load_image(path, scale=None):
    if path.exists():
        img = pygame.image.load(str(path)).convert_alpha()
        if scale:
            img = pygame.transform.smoothscale(img, (int(scale[0]), int(scale[1])))
        return img
    return None

background = load_image(bg_path, (TARGET_WIDTH, TARGET_HEIGHT))
char1_img = load_image(char1_path, BOX_SIZE)
char2_img = load_image(char2_path, BOX_SIZE)
char_btn_img = load_image(char_btn_path, BUTTON_SIZE)
confirm_img = load_image(confirm_path, CONFIRM_SIZE)
titlebox_img = load_image(titlebox_path, (130, 40))
circlebox_img = load_image(circlebox_path)
arrow_img = load_image(arrow_path)

# --------- Rects ----------
box1_pos = (TARGET_WIDTH//3.5, TARGET_HEIGHT//2)
box2_pos = (TARGET_WIDTH*2.5//3.5, TARGET_HEIGHT//2)
char1_rect = char1_img.get_rect(center=box1_pos)
char2_rect = char2_img.get_rect(center=box2_pos)

BUTTON_POS = (TARGET_WIDTH//2, 50)
button_rect = pygame.Rect(BUTTON_POS[0]-BUTTON_SIZE[0]//2, BUTTON_POS[1]-BUTTON_SIZE[1]//2, BUTTON_SIZE[0], BUTTON_SIZE[1])

BACK_BTN_POS = (50, 50)
circlebox_rect = circlebox_img.get_rect(center=BACK_BTN_POS) if circlebox_img else pygame.Rect(BACK_BTN_POS[0]-25, BACK_BTN_POS[1]-25, 50, 50)
arrow_rect = arrow_img.get_rect(center=BACK_BTN_POS) if arrow_img else None

font = pygame.font.Font(str(font_path), 16) if font_path.exists() else pygame.font.SysFont("arial", 16, bold=True)

selected_box = None 

confirm_rect = pygame.Rect(0, 0, *CONFIRM_SIZE)

# --------- Loop หลัก ----------
running = True
while running:
    dt = clock.tick(FPS) / 1000.0
    mouse_pos = pygame.mouse.get_pos()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if circlebox_rect.collidepoint(mouse_pos):
                running = False
                subprocess.Popen([sys.executable, str(ASSET_DIR / "home.py")])
            elif char1_rect.collidepoint(mouse_pos):
                selected_box = "char1"
            elif char2_rect.collidepoint(mouse_pos):
                selected_box = "char2"
            elif selected_box and confirm_rect.collidepoint(mouse_pos):
                print(f"{selected_box} confirmed!")

    # --------- วาด ----------
    if background:
        screen.blit(background, (0, 0))
    else:
        screen.fill((40, 40, 50))

    # ตัวละคร
    if char1_img:
        screen.blit(char1_img, (int(char1_rect.x), int(char1_rect.y)))
    if char2_img:
        screen.blit(char2_img, (int(char2_rect.x), int(char2_rect.y)))

    # วาดกรอบสีเหลืองถ้ามีการเลือก 
    padding = 5  
    height_reduce = 25 

    if selected_box == "char1":
        highlight_rect = char1_rect.inflate(padding*2, 0)  
        highlight_rect.height -= height_reduce 
        highlight_rect.top += height_reduce // 1 
        pygame.draw.rect(screen, (255, 255, 0), highlight_rect, 5)
    elif selected_box == "char2":
        highlight_rect = char2_rect.inflate(padding*2, 0)
        highlight_rect.height -= height_reduce
        highlight_rect.top += height_reduce // 1
        pygame.draw.rect(screen, (255, 255, 0), highlight_rect, 5)

    # TitleBox และข้อความ
    if titlebox_img:
        title_rect1 = titlebox_img.get_rect(center=(char1_rect.centerx, char1_rect.top - titlebox_img.get_height()//2 - 20))
        screen.blit(titlebox_img, (int(title_rect1.x), int(title_rect1.y)))
        title_surf1 = font.render("ลุงหมัดสายฟ้า", True, (255, 255, 255))
        screen.blit(title_surf1, title_surf1.get_rect(center=title_rect1.center))

        title_rect2 = titlebox_img.get_rect(center=(char2_rect.centerx, char2_rect.top - titlebox_img.get_height()//2 - 20))
        screen.blit(titlebox_img, (int(title_rect2.x), int(title_rect2.y)))
        title_surf2 = font.render("นักดาบหลังค่อม", True, (255, 255, 255))
        screen.blit(title_surf2, title_surf2.get_rect(center=title_rect2.center))

    # ปุ่มย้อนกลับ
    if circlebox_img:
        screen.blit(circlebox_img, (int(circlebox_rect.x), int(circlebox_rect.y)))
    if arrow_img:
        screen.blit(arrow_img, (int(arrow_rect.x), int(arrow_rect.y)))

    if char_btn_img:
        screen.blit(char_btn_img, (int(button_rect.x), int(button_rect.y)))

    # ปุ่ม CONFIRM 
    if selected_box:
        confirm_pos = (char1_rect.centerx, char1_rect.bottom + 30) if selected_box=="char1" else (char2_rect.centerx, char2_rect.bottom + 30)
        confirm_rect.center = confirm_pos
        if confirm_img:
            screen.blit(confirm_img, (int(confirm_rect.x), int(confirm_rect.y)))
        else:
            pygame.draw.rect(screen, (0, 200, 100), confirm_rect, border_radius=10)

    pygame.display.flip()

pygame.quit()
sys.exit()
