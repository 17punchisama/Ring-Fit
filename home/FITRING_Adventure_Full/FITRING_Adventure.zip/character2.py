import pygame
import sys
from pathlib import Path
import subprocess

# --------- การตั้งค่า ----------
TARGET_WIDTH = 960
TARGET_HEIGHT = 540
FPS = 60

# --------- เริ่ม Pygame ----------
pygame.init()
clock = pygame.time.Clock()
screen = pygame.display.set_mode((TARGET_WIDTH, TARGET_HEIGHT))
pygame.display.set_caption("FITRING Adventure - Character Selection")

# --------- โหลด assets ----------
ASSET_DIR = Path(__file__).parent
bg_path = ASSET_DIR / "pg/bg1.png"
box_path = ASSET_DIR / "pg/box1.png"
char_path = ASSET_DIR / "pg/characterbox.png"
font_path = ASSET_DIR / "fonts/Itim-Regular.ttf"
valuebar_path = ASSET_DIR / "pg/ValueBar.png"
valueblue_path = ASSET_DIR / "pg/ValueBlue.png"
titlebox_path = ASSET_DIR / "pg/TitleBox.png"
circlebox_path = ASSET_DIR / "pg/CircleBox.png"
arrow_path = ASSET_DIR / "pg/LeftArrowButton.png"
button_path = ASSET_DIR / "pg/Button.png"

# --------- ขนาดกล่องและตัวละคร ----------
BOX_SIZE = (370, 370)
CHAR_WIDTH = 130
CHAR_HEIGHT = 160

# --------- ฟังก์ชันโหลดรูป ----------
def load_image(path, scale=None):
    if path.exists():
        img = pygame.image.load(str(path)).convert_alpha()
        if scale:
            img = pygame.transform.smoothscale(img, scale)
        return img
    return None

background = load_image(bg_path, (TARGET_WIDTH, TARGET_HEIGHT))
box_img = load_image(box_path, BOX_SIZE)
titlebox_img = load_image(titlebox_path, (130, 40))
char_img = load_image(char_path, (CHAR_WIDTH, CHAR_HEIGHT))
valuebar_img = load_image(valuebar_path, (60, 10))
valueblue_img = load_image(valueblue_path, (56, 5))
circlebox_img = load_image(circlebox_path)
arrow_img = load_image(arrow_path)
button_width, button_height = 180, 50
button_img = load_image(button_path, (button_width, button_height))

confirm_width, confirm_height = 100, 35
confirm_img = load_image(button_path, (confirm_width, confirm_height))
confirm_rect = pygame.Rect(0, 0, confirm_width, confirm_height)  # initial rect

# --------- Rects ----------
if box_img:
    box1_rect = box_img.get_rect(center=(TARGET_WIDTH//3.5, TARGET_HEIGHT//2))
    box2_rect = box_img.get_rect(center=(TARGET_WIDTH*2.5//3.5, TARGET_HEIGHT//2))
else:
    box1_rect = pygame.Rect(TARGET_WIDTH//3 - 125, TARGET_HEIGHT//2 - 125, 250, 250)
    box2_rect = pygame.Rect(TARGET_WIDTH*2//3 - 125, TARGET_HEIGHT//2 - 125, 250, 250)

BACK_BTN_POS = (50, 50)
circlebox_rect = circlebox_img.get_rect(center=BACK_BTN_POS) if circlebox_img else pygame.Rect(BACK_BTN_POS[0]-25, BACK_BTN_POS[1]-25, 50, 50)
arrow_rect = arrow_img.get_rect(center=BACK_BTN_POS) if arrow_img else None

# ปุ่ม Character (ด้านบน)
BUTTON_POS = (TARGET_WIDTH//2, 50)
button_rect = button_img.get_rect(center=BUTTON_POS) if button_img else pygame.Rect(BUTTON_POS[0]-button_width//2, BUTTON_POS[1]-button_height//2, button_width, button_height)

# --------- ฟอนต์และข้อความ ----------
font = pygame.font.Font(str(font_path), 11) if font_path.exists() else pygame.font.SysFont("arial", 14)
title_font = pygame.font.Font(str(font_path), 16) if font_path.exists() else pygame.font.SysFont("arial", 16, bold=True)
button_font = pygame.font.Font(str(font_path), 20) if font_path.exists() else pygame.font.SysFont("arial", 20)
confirm_font = pygame.font.Font(str(font_path), 14) if font_path.exists() else pygame.font.SysFont("arial", 14)

button_text = button_font.render("CHARACTER", True, (0, 0, 0))
button_text_rect = button_text.get_rect(center=BUTTON_POS)
confirm_text = confirm_font.render("CONFIRM", True, (0, 0, 0))

# --------- ตัวละครและพลัง ----------
char1_lines = [
    "         ถึงร่างกายจะเปราะบาง",
    "เหมือนกระดาษชุบน้ำ แต่",
    "พลังเวทย์โหดจนใครโดนที",
    "เหมือนถูกฟาดด้วยหม้ออ",
    "ข้าวไฟแรงสุด!",
    "",
    "ATTACK",
    "HP",
    "SPEED",
]
char2_lines = [
    "        นักดาบผู้มีหลังค่อมมาก",
    "ตั้งแต่เด็ก ทำให้ยืนหล่อเท่",
    "แบบพระเอกไม่ได้แต่การ",
    "แกว่งดาบกลับของเขาเร็วยิ่ง",
    "กว่าพัดลมเบอร์ 5",
    "",
    "ATTACK",
    "HP",
    "SPEED",
]

value_dict_char1 = {"ATTACK": 0.8, "HP": 0.5, "SPEED": 0.4}
value_dict_char2 = {"ATTACK": 0.6, "HP": 0.6, "SPEED": 0.5}

char1_surfaces = [font.render(line, True, (255, 215, 0)) for line in char1_lines]
char2_surfaces = [font.render(line, True, (255, 215, 0)) for line in char2_lines]

# --------- ตัวแปรเลือกตัวละคร ----------
selected_box = None  # None, "char1", "char2"

# --------- ฟังก์ชันวาดข้อความตัวละคร ----------
def draw_character_text(char_rect, surfaces, lines, value_dict):
    offset_y = char_rect.top
    for i, surf in enumerate(surfaces):
        text_rect = surf.get_rect(topleft=(char_rect.left + CHAR_WIDTH + 10, offset_y))
        screen.blit(surf, text_rect)

        if valuebar_img and valueblue_img and lines[i] in ["ATTACK", "HP", "SPEED"]:
            bar_x = char_rect.left + CHAR_WIDTH + 60
            bar_y = text_rect.top + (text_rect.height - valuebar_img.get_height()) // 2
            screen.blit(valuebar_img, (bar_x, bar_y))

            val_ratio = value_dict[lines[i]]
            blue_width = int((valuebar_img.get_width() - 4) * val_ratio)
            blue_height = valueblue_img.get_height()
            blue_scaled = pygame.transform.smoothscale(valueblue_img, (blue_width, blue_height))
            inner_x = bar_x + 2
            inner_y = bar_y + (valuebar_img.get_height() - blue_height) // 2
            screen.blit(blue_scaled, (inner_x, inner_y))

        offset_y += surf.get_height() + 6

# --------- Loop หลัก ----------
running = True
while running:
    dt = clock.tick(FPS) / 1000.0
    mouse_pos = pygame.mouse.get_pos()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            # ปุ่มย้อนกลับ
            if circlebox_rect.collidepoint(mouse_pos):
                running = False
                subprocess.Popen([sys.executable, str(ASSET_DIR / "home.py")])
            # ปุ่ม Character
            elif button_rect.collidepoint(mouse_pos):
                print("CHARACTER clicked!")
            # ปุ่ม Confirm
            elif selected_box and confirm_rect.collidepoint(mouse_pos):
                print(f"{selected_box} confirmed!")
            # เลือกตัวละคร
            elif box1_rect.collidepoint(mouse_pos):
                selected_box = "char1"
            elif box2_rect.collidepoint(mouse_pos):
                selected_box = "char2"

    # --------- วาด ---------
    if background:
        screen.blit(background, (0, 0))
    else:
        screen.fill((40, 40, 50))

    # กล่องตัวละคร
    if box_img:
        screen.blit(box_img, box1_rect)
        screen.blit(box_img, box2_rect)
    else:
        pygame.draw.rect(screen, (180, 180, 180), box1_rect)
        pygame.draw.rect(screen, (180, 180, 180), box2_rect)

    # วาดกรอบสีเหลืองถ้ามีการเลือก
    if selected_box == "char1":
        pygame.draw.rect(screen, (255, 255, 0), box1_rect, 5)
    elif selected_box == "char2":
        pygame.draw.rect(screen, (255, 255, 0), box2_rect, 5)

    # ตัวละคร
    if char_img:
        char1_rect = char_img.get_rect(center=(box1_rect.centerx - 55, box1_rect.centery - 20))
        char2_rect = char_img.get_rect(center=(box2_rect.centerx - 55, box2_rect.centery - 20))
        screen.blit(char_img, char1_rect)
        screen.blit(char_img, char2_rect)

    # TitleBox และข้อความ
    if titlebox_img:
        title_rect1 = titlebox_img.get_rect(center=(box1_rect.centerx, char1_rect.top - titlebox_img.get_height()//2 - 40))
        screen.blit(titlebox_img, title_rect1)
        title_surf1 = title_font.render("ลุงหมัดสายฟ้า", True, (255, 255, 255))
        screen.blit(title_surf1, title_surf1.get_rect(center=title_rect1.center))

        title_rect2 = titlebox_img.get_rect(center=(box2_rect.centerx, char2_rect.top - titlebox_img.get_height()//2 - 40))
        screen.blit(titlebox_img, title_rect2)
        title_surf2 = title_font.render("นักดาบหลังค่อม", True, (255, 255, 255))
        screen.blit(title_surf2, title_surf2.get_rect(center=title_rect2.center))

    # ข้อความและ ValueBar
    draw_character_text(char1_rect, char1_surfaces, char1_lines, value_dict_char1)
    draw_character_text(char2_rect, char2_surfaces, char2_lines, value_dict_char2)

    # ปุ่มย้อนกลับ
    if circlebox_img:
        screen.blit(circlebox_img, circlebox_rect)
    if arrow_img:
        screen.blit(arrow_img, arrow_rect)

    # ปุ่ม Character
    if button_img:
        screen.blit(button_img, button_rect)
    else:
        pygame.draw.rect(screen, (80, 150, 300), button_rect, border_radius=10)
    screen.blit(button_text, button_text_rect)

    # --------- วาดปุ่ม CONFIRM เฉพาะเมื่อเลือกตัวละคร ---------
    if selected_box:
        if selected_box == "char1":
            confirm_pos = (box1_rect.centerx, box1_rect.bottom + 30)
        else:
            confirm_pos = (box2_rect.centerx, box2_rect.bottom + 30)

        confirm_rect.center = confirm_pos
        confirm_text_rect = confirm_text.get_rect(center=confirm_rect.center)

        if confirm_img:
            screen.blit(confirm_img, confirm_rect)
        else:
            pygame.draw.rect(screen, (0, 200, 100), confirm_rect, border_radius=10)

        screen.blit(confirm_text, confirm_text_rect)

    pygame.display.flip()

pygame.quit()
sys.exit()
